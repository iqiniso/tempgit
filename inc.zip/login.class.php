<?php
    /**
    * System Login Class.
    * 
    * @author     Brasoveanu Tudor
    * @version    1.2 2011-02-27 
    */

    class login {

        protected static $instance;
        
        /**
        * Instantiate the Login Class.
        *
        * @param void
        * @return Login
        */

        public function __construct() {
            if(!$this->checkSessionVar('uid')) {   //fills session with empty values

            $this->set_session_defaults();

		
            }
            
            if($this->checkSessionVar('logged_in') && $this->getSessionVarVal('logged_in')) {    //already logged in
               
		$this->check_session();
            }

            if ($this->checkSessionVar('remember')) {
                $this->check_remembered();
            }
        }
        
        /**
        * Instantiate the Login Class if it doesn't exist
        * otherwise return the instance that exists
        *
        * @param void
        * @return Login
        */

        public static function getInstance() {
            if (!self::$instance)
            {
                self::$instance = new Login();
            }
            return self::$instance;
        }

        /**
        * Initialize the session variables.
        *
        * @param void
        * @return void
        */

        private function set_session_defaults() {

	///throw new Exception("rar");
           $start = (defined("SESSION_BEGIN") ? SESSION_BEGIN.'_' : '');
            $_SESSION[$start.'logged_in'] = false;
            $_SESSION[$start.'uid'] = 0;
	    $_SESSION[$start.'muid'] = 0;
	    $_SESSION[$start.'username'] = '';
            $_SESSION[$start.'type'] = '';
            $_SESSION[$start.'fname'] = '';
	    $_SESSION[$start.'lang'] = '';
            $_SESSION[$start.'lname'] = '';
            $_SESSION[$start.'email'] = '';
	    $_SESSION[$start.'u_type'] = '';
            $_SESSION[$start.'cookie'] = 0;
            $_SESSION[$start.'remember'] = false;
	   
        }

        /**
        * Login a user if the credentials are correct.
        *
        * @param string $username
        * @param string $password
        * @param bool $remember [optional]
        * @return bool
        */

        public function check_login($data=array()) {
            $remember = false;
            
            if(array_key_exists('password',$data) && strlen($data['password']) > 0)
                $password = md5($data['password']);
            if(array_key_exists('remember',$data))
                $remember = $data['remember'];  
            
            try {
                $db = DB::getInstance();
                
                $query = $db->prepare("SELECT u.*,d.mUID,d.u_type,d.fname,d.lname,d.email_own AS email,d.lang AS lang FROM 4962d92_users_nfo AS u LEFT JOIN 4962d92_users_data AS d ON u.id = d.uid WHERE u.username = :user AND u.password = :password AND u.status = 1 LIMIT 1");
                $query->bindParam(":user",$data['username']);
                $query->bindParam(":password",$password);
                $query->execute();
                
                if($query->rowCount() == 1) {
                    $result = $query->fetch(PDO::FETCH_ASSOC);
                    
                    if($result['lock'] == 0) {
                        $this->set_session($result,$remember,true);
                        
                        return true;
                    } else return false;
                } else return false;
            } catch(PDOException $e) {
                echo $e->getMessage();
            }
            $db = null;
        }
        
        /**
        * Logout user.
        *
        * @param void
        * @return void
        */

        public function logout() {
            $start = (defined("SESSION_BEGIN") ? SESSION_BEGIN.'_' : '');
            setcookie($start.'remember',null,time()-3600);
           // $this->set_session_defaults();
 // $start = (defined("SESSION_BEGIN") ? SESSION_BEGIN.'_' : '');
            $_SESSION[$start.'logged_in'] = false;
           $_SESSION[$start.'uid'] = 0;
			$_SESSION[$start.'muid'] = 0;
			$_SESSION[$start.'username'] = '';
            $_SESSION[$start.'type'] = '';
            $_SESSION[$start.'fname'] = '';
			$_SESSION[$start.'lang'] = '';
            $_SESSION[$start.'lname'] = '';
            $_SESSION[$start.'email'] = '';
			$_SESSION[$start.'u_type'] = '';
            $_SESSION[$start.'cookie'] = 0;
            $_SESSION[$start.'remember'] = false;
            
            return true;
        }
        
        private function set_session($result,$remember,$init = true) {
            @session_regenerate_id();
            $session = session_id();
            $token = $this->token();
            
            if ($init) {
                try {
                    $db = DB::getInstance();
                    
                    $query = $db->prepare("UPDATE 4962d92_users_nfo SET last_log = NOW(), total_log = total_log + 1, session = :session, token = :token WHERE id= :uid");
                    $query->bindParam(":session",$session);
                    $query->bindParam(":token",$token);
                    $query->bindParam(":uid",$result['id']);
                    $query->execute();
                    
                    $db = null;
                } catch(PDOException $e) {
                    echo $e->getMessage();
                }
            }

            $start = (defined("SESSION_BEGIN") ? SESSION_BEGIN.'_' : '');
            $_SESSION[$start.'logged_in'] = true;
            $_SESSION[$start.'uid'] = $result['id'];
			$_SESSION[$start.'muid'] = $result['mUID'];
            $_SESSION[$start.'username'] = $result['username'];
            $_SESSION[$start.'type'] = $result['u_type'];
            $_SESSION[$start.'fname'] = $result['fname'];
            $_SESSION[$start.'lname'] = $result['lname'];
            $_SESSION[$start.'email'] = $result['email'];
			$_SESSION[$start.'lang'] = $result['lang'];
			$_SESSION[$start.'u_type'] = $result['u_type'];
            $_SESSION[$start.'token'] = $token;
            
            if ($remember)
            {
                $this->update_cookie($token);
            }
        }
        
        private function update_cookie($token) {
            $start = (defined("SESSION_BEGIN") ? SESSION_BEGIN.'_' : '');
            $cookie = base64_encode(serialize(array($_SESSION[$start.'username'],$token)));
            setcookie($start.'remember',$cookie, time()+31104000);
        }
        
        private function check_remembered() {
            $username = '';
            $token = '';
            $start = (defined("SESSION_BEGIN") ? SESSION_BEGIN.'_' : '');
            if(isset($_COOKIE[$start.'remember']) && strlen($_COOKIE[$start.'remember']) > 0)
                list($username,$token) = unserialize(base64_decode($_COOKIE[$start.'remember']));
            
            if(empty($email) or empty($token))
            {
                return false;
            } else {
                try {
                    $db = DB::getInstance();
                    $query = $db->prepare("SELECT * FROM 4962d92_users_nfo WHERE username = :user AND token = :token LIMIT 1");
                    $query->bindParam(":user",$username);
                    $query->bindParam(":token",$token);
                    $query->execute();
                    
                    if($query->rowCount() == 1)
                    {
                        $result = $query->fetchAll(PDO::FETCH_ASSOC);
                        $this->set_session($result[0],false,false);    
                    }

                    $db = null;
                } catch(PDOException $e) {
                    echo $e->getMessage();
                }
            }
        }
        
        private function check_session() {
            $start = (defined("SESSION_BEGIN") ? SESSION_BEGIN.'_' : '');
            $session = session_id();
            try {
                $db = DB::getInstance();
                
                $query = $db->prepare("SELECT * FROM 4962d92_users_nfo WHERE username = :user AND token = :token AND session = :session LIMIT 1");
                $query->bindParam(":user",$_SESSION[$start.'username']);
                $query->bindParam(":token",$_SESSION[$start.'token']);
                $query->bindParam(":session",$session);
                $query->execute();
                
                $count = $query->rowCount();
                
                if($count == 0 || $count != 1)
                {
                    $this->logout();  
                }

                $db = null;
            } catch(PDOException $e) {
                echo $e->getMessage();
            }
        }
        
        /**
        * Check if a user is logged in.
        *
        * @param void
        * @return bool
        */

        public function isLogged() {
            $start = (defined("SESSION_BEGIN") ? SESSION_BEGIN.'_' : '');
            if(!isset($_SESSION[$start.'username']) || !isset($_SESSION[$start.'uid']) || !$_SESSION[$start.'logged_in'])
            {
                return false;
            }
            
            return true;
        }
        
        public function isActive() {
            try {
                $db = DB::getInstance();
                
                $uid = $this->getSessionVarVal('uid');
                $query = $db->prepare("SELECT status FROM 4962d92_users_nfo WHERE uid = :uid LIMIT 1");
                $query->bindParam(":uid",$uid);
                $query->execute();
                
                if($query->rowCount() == 1) {
                    $result = $query->fetch(PDO::FETCH_ASSOC);
                    
                    return $result['status'];
                }
            } catch(PDOException $e) {
                echo $e->getMessage();
            }
            $db = null;
            
            return false;
        }
        
        public function hasAccess($access) {
            return ((strcasecmp($this->getSessionVarVal('type'),$access) == 0) ? true : false); 
        }
        
        private function token() {
            $seed="";
            for($i=1;$i<33;$i++)
            {
                $seed .= chr(rand(0,255));
            }

            return md5($seed);
        }
        
        /**
        * Checks if the session name given as the parameter
        * is initialized.
        *
        * @param string $name
        * @return bool
        */
        
        public function checkSessionVar($name) {
            $var = (defined("SESSION_BEGIN") ? SESSION_BEGIN.'_'.$name : $name);            
            return isset($_SESSION[$var]);
        }
        
        /**
        * Gets the value of the session variable which
        * name has been given as parameter.
        *
        * @param string $name
        * @return string or false in case it doesn't exist
        */

        public function getSessionVarVal($name) {
            $var = (defined("SESSION_BEGIN") ? SESSION_BEGIN.'_'.$name : $name);
            
            if(isset($_SESSION[$var]))
                return $_SESSION[$var];
            else
                return false;    
        }
        
        /**
        * Sets the value of the session variable
        *
        * @param string $name
        * @return string or false in case it doesn't exist
        */

        public function setSessionVarVal($name,$value) {
            $var = (defined("SESSION_BEGIN") ? SESSION_BEGIN.'_'.$name : $name);
            
            $_SESSION[$var] = $value;   
        }
        
        public function removeSessionVarVal($name) {
            $var = (defined("SESSION_BEGIN") ? SESSION_BEGIN.'_'.$name : $name);
            
            unset($_SESSION[$var]);   
        }
    }
?>