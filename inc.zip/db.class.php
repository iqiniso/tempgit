<?php
    
    /**
    * System Database Class.
    * 
    * @author     Brasoveanu Tudor
    * @version    1.2 2011-02-27 
    */
    class db {
        /*** Declare instance ***/
        private static $instance = NULL;
        
        /**
        *
        * the constructor is set to private so
        * so nobody can create a new instance using new
        *
        */
        private function __construct() {
            /*** maybe set the db name here later ***/
        }
        
        /**
        *
        * Return DB instance or create intitial connection
        *
        * @return object (PDO)
        *
        * @access public
        *
        */
        public static function getInstance() {
            if (!self::$instance)
            {
                self::$instance = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME,DB_USER,DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
                self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                //ERRMODE_WARNING
            }
            return self::$instance;
        }
        
        /**
        *
        * Like the constructor, we make __clone private
        * so nobody can clone the instance
        *
        */
        private function __clone(){
        }
        
        function checkEmail($email) 
		{
  			if(preg_match("/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)+$/",$email))
 			{
    			return 1;
  			}
  			return 0;
		}
        
    } /*** end of class ***/
?>