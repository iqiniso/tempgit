<?php

	date_default_timezone_set('Asia/Tokyo');
    error_reporting(E_ALL); //E_ALL
    set_time_limit(0);
    
    ini_set('log_errors', 1);
    //ini_set('session.cookie_domain','.tourneyfish.com');
    
    session_start();
    
    //Global variables
    global $db,$login,$template,$referer,$fifthdimension;
    
    include(dirname(__FILE__).'/config.inc.php');
    include(dirname(__FILE__).'/db.class.php');
    include(dirname(__FILE__).'/login.class.php');
    include(dirname(__FILE__).'/functions.php');
    
    $login = LOGIN::getInstance();
    
    //refering page
    $referer = '';
    if(isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER']))
        $referer = strtolower($_SERVER['HTTP_REFERER']);
		
		$fname = $login->getSessionVarVal('fname');
		$lname = $login->getSessionVarVal('lname');
?>