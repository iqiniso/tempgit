<?php
    function check_email_address($email) {
        if (preg_match("/[\\000-\\037]/",$email)) {
            return false;
        }
        $pattern = "/^[-_a-z0-9\'+*$^&%=~!?{}]++(?:\.[-_a-z0-9\'+*$^&%=~!?{}]+)*+@(?:(?![-.])[-a-z0-9.]+(?<![-.])\.[a-z]{2,6}|\d{1,3}(?:\.\d{1,3}){3})(?::\d++)?$/iD";
        if(!preg_match($pattern, $email)){
            return false;
        }
        
        list($user,$domain) = explode('@',$email);
        if( function_exists('checkdnsrr') ) {
            if( !checkdnsrr($domain,"MX") ) { // Linux: PHP 4.3.0 and higher & Windows: PHP 5.3.0 and higher
                return false;
            }
        } else if( function_exists("getmxrr") ) {
            if ( !getmxrr($domain, $mxhosts) ) {
                return false;
            }
        }
        return true;
    }
    
    function gen($length=10)
    {
        $pass = md5(time());
        $pass = substr($pass, 0, $length);
        return $pass;
    }
    
    function email_exists($email)
    {
        try {
            $db = DB::getInstance();
            
            $query = $db->prepare("SELECT * FROM 4962d92_users_data WHERE email_own = :email LIMIT 1");
            $query->execute(array(":email" => $email));
            
            if($query->rowCount() == 1) {
                return true;
            }
        } catch(PDOException $e) {
            echo $e->getMessage();
        }
        $db = null;
        
        return false;
    }
    
    function user_exists($username)
    {
        try {
            $db = DB::getInstance();
            
            $query = $db->prepare("SELECT * FROM 4962d92_users_nfo WHERE username = :user LIMIT 1");
            $query->execute(array(":user" => $username));
            
            if($query->rowCount() == 1) {
                return true;
            }
        } catch(PDOException $e) {
            echo $e->getMessage();
        }
        $db = null;
        
        return false;
    }
    
    function has_add($usid)
    {
        try {
            $db = DB::getInstance();
            
            $query = $db->prepare("SELECT * FROM 4962d92_address WHERE uid = :user LIMIT 1");
            $query->execute(array(":user" => $usid));
            
            if($query->rowCount() == 1) {
                return true;
            }
        } catch(PDOException $e) {
            echo $e->getMessage();
        }
        $db = null;
        
        return false;
    }
    
    function check_password($pass)
    {
        global $login;
        
        try {
            $db = DB::getInstance();
            
            $query = $db->prepare("SELECT * FROM 4962d92_users_nfo WHERE uid = :uid AND password = :pass LIMIT 1");
            $query->execute(array(":uid" => $login->getSessionVarVal('uid'),":pass" => md5($pass)));
            
            if($query->rowCount() == 1) {
                return true;
            }
        } catch(PDOException $e) {
            echo $e->getMessage();
        }
        $db = null;
        
        return false;
    }
    
    function generate_uid()
    {
        $uid = gen();
        
        try {
            $db = DB::getInstance();
            
            $query = $db->prepare("SELECT * FROM 4962d92_users_nfo WHERE id = :uid LIMIT 1");
            $query->execute(array(":uid" => $uid));
            
            while($query->rowCount() > 0) {
                $uid = gen();
                $query = $db->prepare("SELECT * FROM 4962d92_users_nfo WHERE id = :uid LIMIT 1");
                $query->execute(array(":uid" => $uid));    
            }
        } catch(PDOException $e) {
            echo $e->getMessage();
        }
        $db = null;
        
        return $uid;
    }
    
    function id_exists($id) {
        try {
            $db = DB::getInstance();
            
            $query = $db->prepare("SELECT * FROM 4962d92_users_data WHERE uid = :id LIMIT 1");
            $query->execute(array(":id" => $id));
            
            if($query->rowCount() == 1) {
                return true;
            }
        } catch(PDOException $e) {
            echo $e->getMessage();
        }
        $db = null;
        
        return false;
    }
    
	
	    function reset_id_exists($id) {
        try {
            $db = DB::getInstance();
            
            $query = $db->prepare("SELECT * FROM 4962d92_users_nfo WHERE res_token = :id AND NOW() <= DATE_ADD(expire, INTERVAL 24 HOUR) LIMIT 1");
            $query->execute(array(":id" => $id));
            
            if($query->rowCount() == 1) {
                return true;
            }
        } catch(PDOException $e) {
            echo $e->getMessage();
        }
        $db = null;
        
        return false;
    }
	
    function text_limit($s, $l, $e = '...', $isHTML = false){
		$i = 0;
		$tags = array();
		if($isHTML){
			preg_match_all('/<[^>]+>([^<]*)/', $s, $m, PREG_OFFSET_CAPTURE | PREG_SET_ORDER);
			foreach($m as $o){
				if($o[0][1] - $i >= $l)
					break;
				$t = substr(strtok($o[0][0], " \t\n\r\0\x0B>"), 1);
				if($t[0] != '/')
					$tags[] = $t;
				elseif(end($tags) == substr($t, 1))
					array_pop($tags);
				$i += $o[1][1] - $o[0][1];
			}
		}
		return substr($s, 0, $l = min(strlen($s),  $l + $i)) . (count($tags = array_reverse($tags)) ? '</' . implode('></', $tags) . '>' : '') . (strlen($s) > $l ? $e : '');
	}
    
    function ascii2hex($ascii) {
        $hexadecimal = '';
        for ($i = 0; $i < strlen($ascii); $i++) {
            $byte = strtoupper(dechex(ord($ascii{$i})));
            $byte = str_repeat('0', 2 - strlen($byte)).$byte;
            $hexadecimal .= '%'.$byte;
        }
        
        return $hexadecimal;
    }
    
    function hexNonAlpha($string) {
        $arr = str_split($string);
        
        foreach($arr AS $key => $entry) {
            $ret = preg_match("/[^A-Za-z0-9+]/",$entry);
            if($ret) {
                $arr[$key] = '%'.ascii2hex($entry);
            } else {
                $arr[$key] = $entry;
            }
        }
        
        return str_replace(" ","+",implode("",$arr));
    }
	
	
?>