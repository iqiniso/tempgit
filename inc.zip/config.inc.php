<?php
    //database info
  define("DB_HOST","purldb.c40co8pa9ely.us-east-1.rds.amazonaws.com");
	//define("DB_HOST","localhost");
	define("DB_USER","eig77952013");
	define("DB_PASS","ei#63976998?aws");
	define("DB_NAME","ei_stormy_flea");
    
	$url = $_SERVER['HTTP_HOST'];
	$parsedurl = parse_url($url);
	$host = explode('.',$url);
	$subdomain = $host[0];

    //System Variables
    define("SESSION_BEGIN","3goM0n5tatenc0m");
   // define("DOMAIN","http://54.84.67.80/nocturnal_donut");
    define("DOMAIN","https://".$subdomain.".eigomonstar.com");
	define("S_CONT","Eigo Monstar Lesson Planner");
	define("PLANLINK","http://".$subdomain.".eigomonstar.com/functions/_search/ei_view_plan.php?kjsu8=");
	define("ACTLINK","http://".$subdomain.".eigomonstar.com/functions/_search/ei_view_act.php?kjsu8=");
	define("MATLINK","http://".$subdomain.".eigomonstar.com/functions/_search/ei_view_mat.php?kjsu8=");
	define("BOELINK","http://".$subdomain.".eigomonstar.com/functions/_search/ei_view_boe.php?kjsu8=");
         define("SOCIAL","http://social.eigomonstar.com");
	define("S3STORE","http://eigomonstar.s3-website-ap-northeast-1.amazonaws.com/");

        require_once '/var/www/vhosts/english.eigomonstar.com/vendor/autoload.php';
        require_once '/var/www/vhosts/english.eigomonstar.com/vendor/airbrake/airbrake-php/src/Airbrake/EventHandler.php';
        Airbrake\EventHandler::start('aa049301489224ede32145b9a88e2494',true, array('errorReportingLevel' => 'E_ALL'));
?>
