<?php 
class Cms558a39b083dea_2167588424Class extends \Cms\Classes\PartialCode
{

}
