<?php 
class Cms558a39b079d2b_3792847642Class extends \Cms\Classes\PartialCode
{

}
