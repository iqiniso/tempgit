<?php 
class Cms558a39b07de72_284602823Class extends \Cms\Classes\PartialCode
{

}
