<?php 
class Cms558a39b078f0f_1509728078Class extends \Cms\Classes\PartialCode
{

}
