<?php 
class Cms558a39b077f8f_3685357335Class extends \Cms\Classes\PartialCode
{

}
