<?php 
class Cms558a39b082486_149769576Class extends \Cms\Classes\PartialCode
{

}
