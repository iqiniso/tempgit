<?php 
class Cms558a39b05ff73_719387479Class extends \Cms\Classes\PageCode
{

}
