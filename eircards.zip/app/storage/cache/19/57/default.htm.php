<?php 
class Cms558a39b05f83c_2050688349Class extends \Cms\Classes\LayoutCode
{

}
