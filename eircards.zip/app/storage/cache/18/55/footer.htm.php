<?php 
class Cms558a39b084f9f_89771299Class extends \Cms\Classes\PartialCode
{

}
