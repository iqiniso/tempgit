<?php 
class Cms558a39b06a3cd_3133591708Class extends \Cms\Classes\PartialCode
{

}
