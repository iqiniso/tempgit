<?php 
class Cms558a39b081270_3614803576Class extends \Cms\Classes\PartialCode
{

}
