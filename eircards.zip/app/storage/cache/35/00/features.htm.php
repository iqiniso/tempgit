<?php 
class Cms558a39b076b87_652232730Class extends \Cms\Classes\PartialCode
{

}
