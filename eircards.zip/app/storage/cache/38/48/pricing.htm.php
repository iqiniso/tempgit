<?php 
class Cms558a39b080484_3866732339Class extends \Cms\Classes\PartialCode
{

}
