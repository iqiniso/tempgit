<?php 
class Cms558a39b06f87e_347113943Class extends \Cms\Classes\PartialCode
{

}
