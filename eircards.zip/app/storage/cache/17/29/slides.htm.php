<?php 
class Cms558a39b070846_2774157032Class extends \Cms\Classes\PartialCode
{

}
