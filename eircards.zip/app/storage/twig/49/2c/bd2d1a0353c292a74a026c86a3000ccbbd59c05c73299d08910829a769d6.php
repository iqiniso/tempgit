<?php

/* /var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/about.htm */
class __TwigTemplate_492cbd2d1a0353c292a74a026c86a3000ccbbd59c05c73299d08910829a769d6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">

            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">How They Work</h2>
                <p class=\"text-center wow fadeInDown\">The cards have been assembled using a mathematical algorithm that naturalises the teaching process. The combinations included provide multiple opportunities to spiral the language the kids are learning. The algorithm also randomises the options on the front and back of the cards ensuring that the children do not get used to the cards. They cannot memorise what is on the cards so each lesson is like they are starting out with a fresh set of cards. This is crucial to maintaining excitement around the cards and enables the exploration of target language designed around clarifying questions. </p>

<p class=\"text-center wow fadeInDown\">When asking “What food do you like?” for example the child posing the question to his or her colleague is genuinely unaware of what option the other student has. This is essential in connecting the emotions to the words and the thought process, which fundamental in building fluency.The algorithm helps teach the kids <em>how</em> to learn a new language, not just a bunch of words.</p>

<p class=\"text-center wow fadeInDown\">The cards cover the three key aspects of learning namely visual, auditory, and kinesthetic. The beautiful graphics engage visual learners, the cards and activities encourage  students to move about the classroom and interact with one another which promotes both listening and speaking.</p>

<p class=\"text-center wow fadeInDown\">Thus for teachers at any level most of the material prep has been taken care of so you can focus on creating an environment in which your students can learn effectively.</p>
            </div>

            <div class=\"row\">
                <div class=\"col-sm-6 wow fadeInLeft\">
                    ";
        // line 16
        echo $this->env->getExtension('CMS')->contentFunction("about/video.htm"        );
        // line 17
        echo "                </div>

                <div class=\"col-sm-6 wow fadeInRight\">
                    ";
        // line 20
        echo $this->env->getExtension('CMS')->contentFunction("about/capabilities.htm"        );
        // line 21
        echo "                </div>
        </div>";
    }

    public function getTemplateName()
    {
        return "/var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/about.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  45 => 21,  43 => 20,  38 => 17,  36 => 16,  19 => 1,);
    }
}
