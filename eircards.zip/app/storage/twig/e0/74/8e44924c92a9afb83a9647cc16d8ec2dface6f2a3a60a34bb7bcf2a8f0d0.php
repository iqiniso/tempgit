<?php

/* /var/www/vhosts/eicards.com/htdocs/plugins/srlabs/piwik/components/piwik/default.htm */
class __TwigTemplate_e0748e44924c92a9afb83a9647cc16d8ec2dface6f2a3a60a34bb7bcf2a8f0d0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- Piwik -->
<script type=\"text/javascript\">
    var _paq = _paq || [];
    _paq.push(['trackPageView']);
    _paq.push(['enableLinkTracking']);
    (function() {
        var u=((\"https:\" == document.location.protocol) ? \"https\" : \"http\") + \"://";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["__SELF__"]) ? $context["__SELF__"] : null), "trackerDomain", array()), "html", null, true);
        echo "/\";
        _paq.push(['setTrackerUrl', u+'piwik.php']);
        _paq.push(['setSiteId', ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["__SELF__"]) ? $context["__SELF__"] : null), "siteId", array()), "html", null, true);
        echo " ]);
        var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0]; g.type='text/javascript';
        g.defer=true; g.async=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
    })();
</script>
<noscript><p><img src=\"http://";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["__SELF__"]) ? $context["__SELF__"] : null), "trackerDomain", array()), "html", null, true);
        echo "/piwik.php?idsite=";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["__SELF__"]) ? $context["__SELF__"] : null), "siteId", array()), "html", null, true);
        echo "\" style=\"border:0;\" alt=\"\" /></p></noscript>
<!-- End Piwik Code -->

";
    }

    public function getTemplateName()
    {
        return "/var/www/vhosts/eicards.com/htdocs/plugins/srlabs/piwik/components/piwik/default.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 14,  32 => 9,  27 => 7,  19 => 1,);
    }
}
