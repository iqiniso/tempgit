<?php

/* /var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/pages/home.htm */
class __TwigTemplate_0929b951f6a76902187e4d3dae5056372f45a22ed5e92850a01374f8ed43d3a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "/var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/pages/home.htm";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
