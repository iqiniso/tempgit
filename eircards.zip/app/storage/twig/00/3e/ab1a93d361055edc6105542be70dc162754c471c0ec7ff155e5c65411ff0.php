<?php

/* /var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/contact.htm */
class __TwigTemplate_003eab1a93d361055edc6105542be70dc162754c471c0ec7ff155e5c65411ff0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"google-map\" style=\"height:650px\" data-latitude=\"35.665076\" data-longitude=\"139.751153\"></div>
        <div class=\"container-wrapper\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-4 col-sm-offset-8\">
                        <div class=\"contact-form\">
                            <h3>Contact Info</h3>

                            <address>
                              <strong>Ei Cards Japan</strong><br>
                              Level 14 Hibiya Central Building<br>
                              1-2-9 Nishi Shimbashi Minato-Ku<br>
                              Tokyo 105-0003 Japan<br>
                              <abbr title=\"Phone\">Tel:</abbr> +81 92 419 2300
                            </address>

                            <form role=\"form\"
      data-request=\"";
        // line 18
        echo twig_escape_filter($this->env, (isset($context["mailTemplate"]) ? $context["mailTemplate"] : null), "html", null, true);
        echo "::onOctoMailSent\"
      data-request-update=\"'";
        // line 19
        echo twig_escape_filter($this->env, (isset($context["mailTemplate"]) ? $context["mailTemplate"] : null), "html", null, true);
        echo "::confirm': '.confirm-container'\"
      data-request-success=\"\$('.form-groups').slideUp(1000)\">

    <div class=\"form-groups\">
    <div class=\"form-group\">
        <input type=\"text\" class=\"form-control\" value=\"\"  name=\"name\" placeholder=\"Enter name\">
    </div>
    <div class=\"form-group\">
        <input type=\"text\" class=\"form-control\" value=\"\" name=\"email\" placeholder=\"Enter Email\">
    </div>
    <div class=\"form-group\">
        <input type=\"text\" class=\"form-control\" value=\"\"  name=\"phone\" placeholder=\"Enter phone\">
    </div>
    <div class=\"form-group\">
        <input type=\"text\" class=\"form-control\" value=\"\" name=\"subject\" placeholder=\"Enter Subject\">
    </div>
    <div class=\"form-group\">
        <textarea class=\"form-control\" value=\"\" name=\"body\" placeholder=\"Enter Message\" cols=\"30\" rows=\"3\"></textarea>
    </div>
    <button type=\"submit\" class=\"btn btn-primary btn-lg pull-right\">Send</button>
    </div>

    <div class=\"confirm-container\">
    <!--This will contain the confirmation when the email is successfully sent-->
    </div>
</form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>";
    }

    public function getTemplateName()
    {
        return "/var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/contact.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  42 => 19,  38 => 18,  19 => 1,);
    }
}
