<?php

/* /var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/services.htm */
class __TwigTemplate_5cc842e153f1b0024eaed7b610caffd3e211358098b24652a689bacf8370340f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">Key Benefits</h2>
                <p class=\"text-center wow fadeInDown\">There are many great reasons to get your set of Ei Cards without delay. These are just a few but once you start using them you will probably think up more than we could!</p>
            </div>

            <div class=\"row\">
                <div class=\"features\">
                    <div class=\"col-md-4 col-sm-6 wow fadeInUp\" data-wow-duration=\"300ms\" data-wow-delay=\"0ms\">
                        <div class=\"media service-box\">
                            <div class=\"pull-left\">
                                <i class=\"fa fa-line-chart\"></i>
                            </div>
                            <div class=\"media-body\">
                                <h4 class=\"media-heading\">Zero Prep</h4>
                                <p>With just a handful of cards, you can walk into your classroom and teach English as a second language from a standing start.</p>
                            </div>
                        </div>
                    </div><!--/.col-md-4-->

                    <div class=\"col-md-4 col-sm-6 wow fadeInUp\" data-wow-duration=\"300ms\" data-wow-delay=\"100ms\">
                        <div class=\"media service-box\">
                            <div class=\"pull-left\">
                                <i class=\"fa fa-cubes\"></i>
                            </div>
                            <div class=\"media-body\">
                                <h4 class=\"media-heading\">Grade Specific</h4>
                                <p>Each teaching level has its own set of cards giving you access to developmentally appropriate teaching topics.</p>
                            </div>
                        </div>
                    </div><!--/.col-md-4-->

                    <div class=\"col-md-4 col-sm-6 wow fadeInUp\" data-wow-duration=\"300ms\" data-wow-delay=\"200ms\">
                        <div class=\"media service-box\">
                            <div class=\"pull-left\">
                                <i class=\"fa fa-pie-chart\"></i>
                            </div>
                            <div class=\"media-body\">
                                <h4 class=\"media-heading\">Experience Included</h4>
                                <p>The cards have been developed by qualified teachers with many years of experience in teaching as well as Assistant Language teachers who understand the challenges of learning to teach on the fly.</p>
                            </div>
                        </div>
                    </div><!--/.col-md-4-->
                
                    <div class=\"col-md-4 col-sm-6 wow fadeInUp\" data-wow-duration=\"300ms\" data-wow-delay=\"300ms\">
                        <div class=\"media service-box\">
                            <div class=\"pull-left\">
                                <i class=\"fa fa-bar-chart\"></i>
                            </div>
                            <div class=\"media-body\">
                                <h4 class=\"media-heading\">Online Support</h4>
                                <p>The online application will give you access to many types of lesson plans tailored to each grade. These will ensure you hit the ground running when you get your cards.</p>
                            </div>
                        </div>
                    </div><!--/.col-md-4-->

                    <div class=\"col-md-4 col-sm-6 wow fadeInUp\" data-wow-duration=\"300ms\" data-wow-delay=\"400ms\">
                        <div class=\"media service-box\">
                            <div class=\"pull-left\">
                                <i class=\"fa fa-language\"></i>
                            </div>
                            <div class=\"media-body\">
                                <h4 class=\"media-heading\">Durability</h4>
                                <p>The cards are designed to last. They are made from high quality materials that will stand up to the kinds of punishment meted out by over enthusiastic kids.</p>
                            </div>
                        </div>
                    </div><!--/.col-md-4-->

                    <div class=\"col-md-4 col-sm-6 wow fadeInUp\" data-wow-duration=\"300ms\" data-wow-delay=\"500ms\">
                        <div class=\"media service-box\">
                            <div class=\"pull-left\">
                                <i class=\"fa fa-bullseye\"></i>
                            </div>
                            <div class=\"media-body\">
                                <h4 class=\"media-heading\">Socially Aware</h4>
                                <p>For every 4 sets of cards that we sell, we will donate one set to a school in an area that serves marginalised communities.</p>
                            </div>
                        </div>
                    </div><!--/.col-md-4-->
                </div>
            </div><!--/.row-->    
        </div><!--/.container-->";
    }

    public function getTemplateName()
    {
        return "/var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/services.htm";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
