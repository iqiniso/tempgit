<?php

/* /var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/portfolio.htm */
class __TwigTemplate_88a9f37b559a1d307d062ad94f7de4df660b96fe3aa8461b53f8a03538cd9daf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">Card Artwork</h2>
                <p class=\"text-center wow fadeInDown\">The bright colours and clear graphics have been designed to help stimulate young minds. They let the kids know that it is time to learn and it is going to be lots of fun!</p>
            </div>

            <div class=\"text-center\">
                <ul class=\"portfolio-filter\">
                    <li><a class=\"active\" href=\"#\" data-filter=\"*\">All Samples</a></li>
                    <li><a href=\"#\" data-filter=\".es12\">Elementary 1 - 2</a></li>
                    <li><a href=\"#\" data-filter=\".es34\">Elementary 3 - 4</a></li>
                    <li><a href=\"#\" data-filter=\".es56\">Elementary 5 - 6</a></li>
                </ul><!--/#portfolio-filter-->
            </div>

            <div class=\"portfolio-items\">
                <div class=\"portfolio-item es12\">
                    <div class=\"portfolio-item-inner\">
                        <img class=\"img-responsive\" src=\"";
        // line 19
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/01.jpg");
        echo "\" alt=\"\">
                        <div class=\"portfolio-info\">
                            <h3>Elementary 1 - 2</h3>
                            Dog
                            <a class=\"preview\" href=\"";
        // line 23
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/01.jpg");
        echo "\" rel=\"prettyPhoto\"><i class=\"fa fa-eye\"></i></a>
                        </div>
                    </div>
                </div><!--/.portfolio-item-->

                <div class=\"portfolio-item es34\">
                    <div class=\"portfolio-item-inner\">
                        <img class=\"img-responsive\" src=\"";
        // line 30
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/02.jpg");
        echo "\" alt=\"\">
                        <div class=\"portfolio-info\">
                            <h3>Elementary</h3>
                            Lion
                            <a class=\"preview\" href=\"";
        // line 34
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/02.jpg");
        echo "\" rel=\"prettyPhoto\"><i class=\"fa fa-eye\"></i></a>
                        </div>
                    </div>
                </div><!--/.portfolio-item-->

                <div class=\"portfolio-item es12\">
                    <div class=\"portfolio-item-inner\">
                        <img class=\"img-responsive\" src=\"";
        // line 41
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/03.jpg");
        echo "\" alt=\"\">
                        <div class=\"portfolio-info\">
                            <h3>Elementary 1 - 2</h3>
                           Pig
                            <a class=\"preview\" href=\"";
        // line 45
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/03.jpg");
        echo "\" rel=\"prettyPhoto\"><i class=\"fa fa-eye\"></i></a>
                        </div>
                    </div>
                </div><!--/.portfolio-item-->

                <div class=\"portfolio-item es56\">
                    <div class=\"portfolio-item-inner\">
                        <img class=\"img-responsive\" src=\"";
        // line 52
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/04.jpg");
        echo "\" alt=\"\">
                        <div class=\"portfolio-info\">
                            <h3>Elementary 5 - 6</h3>
                            Policeman
                            <a class=\"preview\" href=\"";
        // line 56
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/04.jpg");
        echo "\" rel=\"prettyPhoto\"><i class=\"fa fa-eye\"></i></a>
                        </div>
                    </div>
                </div><!--/.portfolio-item-->

                <div class=\"portfolio-item es12\">
                    <div class=\"portfolio-item-inner\">
                        <img class=\"img-responsive\" src=\"";
        // line 63
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/05.jpg");
        echo "\" alt=\"\">
                        <div class=\"portfolio-info\">
                            <h3>Elementary 1 - 2</h3>
                            Rabbit 
                            <a class=\"preview\" href=\"";
        // line 67
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/05.jpg");
        echo "\" rel=\"prettyPhoto\"><i class=\"fa fa-eye\"></i></a>
                        </div>
                    </div>
                </div><!--/.portfolio-item-->

                <div class=\"portfolio-item es56\">
                    <div class=\"portfolio-item-inner\">
                        <img class=\"img-responsive\" src=\"";
        // line 74
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/06.jpg");
        echo "\" alt=\"\">
                        <div class=\"portfolio-info\">
                            <h3>Elementary 5 - 6</h3>
                            Engineer
                            <a class=\"preview\" href=\"";
        // line 78
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/06.jpg");
        echo "\" rel=\"prettyPhoto\"><i class=\"fa fa-eye\"></i></a>
                        </div>
                    </div>
                </div><!--/.portfolio-item-->

                <div class=\"portfolio-item es34\">
                    <div class=\"portfolio-item-inner\">
                        <img class=\"img-responsive\" src=\"";
        // line 85
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/07.jpg");
        echo "\" alt=\"\">
                        <div class=\"portfolio-info\">
                            <h3>Elementary 3 - 4</h3>
                            Penguin
                            <a class=\"preview\" href=\"";
        // line 89
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/07.jpg");
        echo "\" rel=\"prettyPhoto\"><i class=\"fa fa-eye\"></i></a>
                        </div>
                    </div>
                </div><!--/.portfolio-item-->

                <div class=\"portfolio-item es12\">
                    <div class=\"portfolio-item-inner\">
                        <img class=\"img-responsive\" src=\"";
        // line 96
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/08.jpg");
        echo "\" alt=\"\">
                        <div class=\"portfolio-info\">
                            <h3>Elementary 1 - 2</h3>
                            Horse
                            <a class=\"preview\" href=\"";
        // line 100
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/08.jpg");
        echo "\" rel=\"prettyPhoto\"><i class=\"fa fa-eye\"></i></a>
                        </div>
                    </div>
                </div><!--/.portfolio-item-->
                
                <div class=\"portfolio-item es56\">
                    <div class=\"portfolio-item-inner\">
                        <img class=\"img-responsive\" src=\"";
        // line 107
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/09.jpg");
        echo "\" alt=\"\">
                        <div class=\"portfolio-info\">
                            <h3>Elementary 5 - 6</h3>
                            Chef
                            <a class=\"preview\" href=\"";
        // line 111
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/09.jpg");
        echo "\" rel=\"prettyPhoto\"><i class=\"fa fa-eye\"></i></a>
                        </div>
                    </div>
                </div><!--/.portfolio-item-->
                
                <div class=\"portfolio-item es34\">
                    <div class=\"portfolio-item-inner\">
                        <img class=\"img-responsive\" src=\"";
        // line 118
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/10.jpg");
        echo "\" alt=\"\">
                        <div class=\"portfolio-info\">
                            <h3>Elementary 3 - 4</h3>
                            Elephant
                            <a class=\"preview\" href=\"";
        // line 122
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/10.jpg");
        echo "\" rel=\"prettyPhoto\"><i class=\"fa fa-eye\"></i></a>
                        </div>
                    </div>
                </div><!--/.portfolio-item-->

                <div class=\"portfolio-item es56\">
                    <div class=\"portfolio-item-inner\">
                        <img class=\"img-responsive\" src=\"";
        // line 129
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/11.jpg");
        echo "\" alt=\"\">
                        <div class=\"portfolio-info\">
                            <h3>Elementary 5 - 6</h3>
                            Florist
                            <a class=\"preview\" href=\"";
        // line 133
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/11.jpg");
        echo "\" rel=\"prettyPhoto\"><i class=\"fa fa-eye\"></i></a>
                        </div>
                    </div>
                </div><!--/.portfolio-item-->


                <div class=\"portfolio-item es34\">
                    <div class=\"portfolio-item-inner\">
                        <img class=\"img-responsive\" src=\"";
        // line 141
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/12.jpg");
        echo "\" alt=\"\">
                        <div class=\"portfolio-info\">
                            <h3>Elementary 3 - 4</h3>
                            Panda
                            <a class=\"preview\" href=\"";
        // line 145
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/portfolio/12.jpg");
        echo "\" rel=\"prettyPhoto\"><i class=\"fa fa-eye\"></i></a>
                        </div>
                    </div>
                </div><!--/.portfolio-item-->
                </div>
        </div><!--/.container-->";
    }

    public function getTemplateName()
    {
        return "/var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/portfolio.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  234 => 145,  227 => 141,  216 => 133,  209 => 129,  199 => 122,  192 => 118,  182 => 111,  175 => 107,  165 => 100,  158 => 96,  148 => 89,  141 => 85,  131 => 78,  124 => 74,  114 => 67,  107 => 63,  97 => 56,  90 => 52,  80 => 45,  73 => 41,  63 => 34,  56 => 30,  46 => 23,  39 => 19,  19 => 1,);
    }
}
