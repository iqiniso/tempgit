<?php

/* /var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/blogs.htm */
class __TwigTemplate_f49ab7fe6333be162b6b6657fd1a262cc31d630acb2d4b7946ae0ed51d7ab78f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">Latest News</h2>
                <p class=\"text-center wow fadeInDown\">The cards are out on production and there are many things happening. Keep up to date by following us on facebook. <br> We will keep you updated as new materials associated with the cards become available so stay tuned!</p>
            </div>

            <div class=\"row\">
                <div class=\"col-sm-6\">
                    <div class=\"blog-post blog-large wow fadeInLeft\" data-wow-duration=\"300ms\" data-wow-delay=\"0ms\">
                        <article>
                            <header class=\"entry-header\">
                                <div class=\"entry-thumbnail\">
                                    <img class=\"img-responsive\" src=\"";
        // line 13
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/blog/01.jpg");
        echo "\" alt=\"\">
                                    <span class=\"post-format post-format-video\"><i class=\"fa fa-film\"></i></span>
                                </div>
                                <div class=\"entry-date\">17 January 2015</div>
                                <h2 class=\"entry-title\"><a href=\"#\">Crowd funding project comes to an end.</a></h2>
                            </header>

                            <div class=\"entry-content\">
                                <P>We finished our fund raising campaign on IndieGOGO. It was a great excercise and gave us a chance to put our ideas to the world and get some really great feedback which has helped shaped the development of the cards.</P>
                            </div>

                            <footer class=\"entry-meta\">
                                <span class=\"entry-author\"><i class=\"fa fa-pencil\"></i> <a href=\"#\">January</a></span>
                                <span class=\"entry-category\"><i class=\"fa fa-folder-o\"></i> <a href=\"#\">News</a></span>
                                
                            </footer>
                        </article>
                    </div>
                </div><!--/.col-sm-6-->
                <div class=\"col-sm-6\">
                    <div class=\"blog-post blog-media wow fadeInRight\" data-wow-duration=\"300ms\" data-wow-delay=\"100ms\">
                        <article class=\"media clearfix\">
                            <div class=\"entry-thumbnail pull-left\">
                                <img class=\"img-responsive\" src=\"";
        // line 36
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/blog/02.jpg");
        echo "\" alt=\"\">
                                <span class=\"post-format post-format-gallery\"><i class=\"fa fa-image\"></i></span>
                            </div>
                            <div class=\"media-body\">
                                <header class=\"entry-header\">
                                    <div class=\"entry-date\">18 January 2015</div>
                                    <h2 class=\"entry-title\"><a href=\"#\">Beta Developments</a></h2>
                                </header>

                                <div class=\"entry-content\">
                                    <P>The first cards are out and ready for you to buy. Combined with the online lesson planning system, this will add punch to your teaching!</P>
                                </div>

                                <footer class=\"entry-meta\">
                                    <span class=\"entry-author\"><i class=\"fa fa-pencil\"></i> <a href=\"#\">January</a></span>
                                    <span class=\"entry-category\"><i class=\"fa fa-folder-o\"></i> <a href=\"#\">Development</a></span>
                                </footer>
                            </div>
                        </article>
                    </div>
                    <div class=\"blog-post blog-media wow fadeInRight\" data-wow-duration=\"300ms\" data-wow-delay=\"200ms\">
                        <article class=\"media clearfix\">
                            <div class=\"entry-thumbnail pull-left\">
                                <img class=\"img-responsive\" src=\"";
        // line 59
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/blog/03.jpg");
        echo "\" alt=\"\">
                                <span class=\"post-format post-format-audio\"><i class=\"fa fa-music\"></i></span>
                            </div>
                            <div class=\"media-body\">
                                <header class=\"entry-header\">
                                    <div class=\"entry-date\">19 January 2015</div>
                                    <h2 class=\"entry-title\"><a href=\"http://eigomonstar.com/index.php/k2-tags/shop-online\">Online Store Open</a></h2>
                                </header>

                                <div class=\"entry-content\">
                                    <P>The online store is up on EigoMonstar and you can buy loads of materials from there. Check it out today!</P>
                                    <a class=\"btn btn-primary\" href=\"http://eigomonstar.com/index.php/k2-tags/shop-online\">Visit Store</a>
                                </div>

                                <footer class=\"entry-meta\">
                                    <span class=\"entry-author\"><i class=\"fa fa-pencil\"></i> <a href=\"#\">January</a></span>
                                    <span class=\"entry-category\"><i class=\"fa fa-folder-o\"></i> <a href=\"#\">News</a></span>
                                </footer>
                            </div>
                        </article>
                    </div>
                </div>
            </div>

        </div>";
    }

    public function getTemplateName()
    {
        return "/var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/blogs.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 59,  59 => 36,  33 => 13,  19 => 1,);
    }
}
