<?php

/* /var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/pricing.htm */
class __TwigTemplate_ddb8ae190e29cb755e2b03a0e109040f52841bfbe64f9fe785fc229f834d9150 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">Pricing</h2>
                <p class=\"text-center wow fadeInDown\">The cards are priced to go! They also INCLUDE free access to the online lesson planner worth \$125! This is a <strong>LIMITED TIME</strong> offer so hurry!</p>
            </div>

            <div class=\"row\">
                <div class=\"col-sm-6 col-md-3\">
                    <div class=\"wow zoomIn\" data-wow-duration=\"400ms\" data-wow-delay=\"0ms\">
                        <ul class=\"pricing\">
                            <li class=\"plan-header\">
                                <div class=\"price-duration\">
                                    <span class=\"price\">
                                        \$12
                                    </span>
                                    <span class=\"duration\">
                                        12 cards
                                    </span>
                                </div>

                                <div class=\"plan-name\">
                                    12 Cards
                                </div>
                            </li>
                            <li><strong>Replacement</strong> Cards</li>
                            <li><strong>12 </strong>10x10cm cards</li>
                            <li><strong>SUPER</strong> durable</li>
                            <li>Full Colour</li>
                            <li>Laminated</li>
                            <li>No Online Acces</li>
                            <li class=\"plan-purchase\"><a class=\"btn btn-primary\" href=\"#\">ORDER NOW</a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-sm-6 col-md-3\">
                    <div class=\"wow zoomIn\" data-wow-duration=\"400ms\" data-wow-delay=\"200ms\">
                        <ul class=\"pricing featured\">
                            <li class=\"plan-header\">
                                <div class=\"price-duration\">
                                    <span class=\"price\">
                                        \$50
                                    </span>
                                    <span class=\"duration\">
                                        132 Cards
                                    </span>
                                </div>

                                <div class=\"plan-name\">
                                    single
                                </div>
                            </li>
                            <li><strong>Full</strong> Set</li>
                            <li><strong>132</strong> 10x10cm Cards</li>
                            <li><strong>26</strong> A4 cards</li>
                            <li>1 year online access</li>
                            <li>Full Colour</li>
                            <li>Laminated</li>
                            <li class=\"plan-purchase\"><a class=\"btn btn-default\" href=\"http://eigomonstar.com/index.php/k2-tags/shop-online/ei-cards/ei-cards-1-38-2-pack-detail\">ORDER NOW</a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-sm-6 col-md-3\">
                    <div class=\"wow zoomIn\" data-wow-duration=\"400ms\" data-wow-delay=\"400ms\">
                        <ul class=\"pricing\">
                            <li class=\"plan-header\">
                                <div class=\"price-duration\">
                                    <span class=\"price\">
                                        \$80
                                    </span>
                                    <span class=\"duration\">
                                        264 cards
                                    </span>
                                </div>

                                <div class=\"plan-name\">
                                    double
                                </div>
                            </li>
                            <li><strong>Double</strong> Set</li>
                            <li><strong>264</strong> 10x10cm Cards</li>
                            <li><strong>52</strong> A4 cards</li>
                            <li>1 year online access</li>
                            <li>Full Colour</li>
                            <li>Laminated</li>
                            <li class=\"plan-purchase\"><a class=\"btn btn-primary\" href=\"http://eigomonstar.com/index.php/k2-tags/shop-online/ei-cards/ei-cards-1-38-2-pack-3-4-detail\">ORDER NOW</a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-sm-6 col-md-3\">
                    <div class=\"wow zoomIn\" data-wow-duration=\"400ms\" data-wow-delay=\"600ms\">
                        <ul class=\"pricing\">
                            <li class=\"plan-header\">
                                <div class=\"price-duration\">
                                    <span class=\"price\">
                                        \$120
                                    </span>
                                    <span class=\"duration\">
                                        396 cards
                                    </span>
                                </div>

                                <div class=\"plan-name\">
                                    Full house
                                </div>
                            </li>
                            <li><strong>Triple</strong> Set</li>
                            <li><strong>396</strong> 10x10cm Cards</li>
                            <li><strong>78</strong> A4 cards</li>
                            <li>2 years online access</li>
                            <li>Full Colour</li>
                            <li>Laminated</li>
                            <li class=\"plan-purchase\"><a class=\"btn btn-primary\" href=\"http://eigomonstar.com/index.php/k2-tags/shop-online/ei-cards/ei-cards-1-38-2-pack-3-4-6-detail\">ORDER NOW</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>";
    }

    public function getTemplateName()
    {
        return "/var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/pricing.htm";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
