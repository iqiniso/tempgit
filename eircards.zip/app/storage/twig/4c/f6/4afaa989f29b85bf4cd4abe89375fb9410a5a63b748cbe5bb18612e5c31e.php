<?php

/* /var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/footer.htm */
class __TwigTemplate_4cf64afaa989f29b85bf4cd4abe89375fb9410a5a63b748cbe5bb18612e5c31e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-6\">
                    ©  ";
        // line 4
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["this"]) ? $context["this"] : null), "theme", array()), "site_name", array()), "html", null, true);
        echo ". Designed by <a target=\"_blank\" href=\"http://eicards.com/\" title=\"Ei Cards\">Ei Cards</a> 
                </div>
                <div class=\"col-sm-6\">
                    <ul class=\"social-icons\">
                        <li><a href=\"https://www.facebook.com/eicards\"><i class=\"fa fa-facebook\"></i></a></li>
                        <li><a href=\"https://twitter.com/ei_cards\"><i class=\"fa fa-twitter\"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>";
    }

    public function getTemplateName()
    {
        return "/var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/footer.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  24 => 4,  19 => 1,);
    }
}
