<?php

/* /var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/features.htm */
class __TwigTemplate_ac04b07890f13c763afc7a097e01334f1a719aa3f3c5843745d3b1c2cc2f028e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">Awesome Lesson Planner</h2>
                <p class=\"text-center wow fadeInDown\">The cards are supported by an online applicatiom that will forever change the way you view your lesson planning. </p>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-6 wow fadeInLeft\">
                    <img class=\"img-responsive\" src=\"";
        // line 8
        echo $this->env->getExtension('CMS')->themeFilter("assets/images/main-feature.png");
        echo "\" alt=\"\">
                </div>
                <div class=\"col-sm-6\">
                    <div class=\"media service-box wow fadeInRight\">
                        <div class=\"pull-left\">
                            <i class=\"fa fa-line-chart\"></i>
                        </div>
                        <div class=\"media-body\">
                            <h4 class=\"media-heading\">Be  effective</h4>
                            <p>View pre-prepared lesson plans that will help you use the cards to their full potential.</p>
                        </div>
                    </div>

                    <div class=\"media service-box wow fadeInRight\">
                        <div class=\"pull-left\">
                            <i class=\"fa fa-cubes\"></i>
                        </div>
                        <div class=\"media-body\">
                            <h4 class=\"media-heading\">Be organised</h4>
                            <p>Upload your own materials and create your own activites and lesson plans. Everything in one place!</p>
                        </div>
                    </div>

                    <div class=\"media service-box wow fadeInRight\">
                        <div class=\"pull-left\">
                            <i class=\"fa fa-star\"></i>
                        </div>
                        <div class=\"media-body\">
                            <h4 class=\"media-heading\">Be Fresh</h4>
                            <p>Each week we will supply new lesson plans based on the cards to ensure that you are stimulating the young minds you are responsible for.</p>
                        </div>
                    </div>

                    <div class=\"media service-box wow fadeInRight\">
                        <div class=\"pull-left\">
                            <i class=\"fa fa-share-alt\"></i>
                        </div>
                        <div class=\"media-body\">
                            <h4 class=\"media-heading\">Be Social</h4>
                            <p>Share your lesson plans with other teachers about how they are using the cards and get instant feedback on your lesson plans.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>";
    }

    public function getTemplateName()
    {
        return "/var/www/vhosts/eicards.com/htdocs/themes/jtherczeg-multi/partials/features.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 8,  19 => 1,);
    }
}
